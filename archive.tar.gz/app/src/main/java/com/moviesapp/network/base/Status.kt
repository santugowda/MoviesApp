package com.moviesapp.network.base

enum class Status {
    SUCCESS,
    ERROR,
    LOADING,
    EMPTY
}