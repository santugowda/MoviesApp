package com.moviesapp.utils

object MovieConstants {

    const val MOVIES_BASE_URL : String = "https://www.omdbapi.com/"
    const val TIME_OUT: Long = 30
    public const val API_KEY = "a18487bc"

}